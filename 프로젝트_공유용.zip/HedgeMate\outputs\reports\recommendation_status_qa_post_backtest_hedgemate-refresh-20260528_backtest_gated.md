# HedgeMate Recommendation Status QA (Post-Backtest)

- generated_at_utc: 2026-05-28T02:06:00Z
- hedgemate_run_id: hedgemate-refresh-20260528
- backtest_run_id: backtest-refresh-20260528
- basis: post-backtest gated recommendation CSVs
- portfolio_1to1_gated_csv: C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\portfolio_1to1_hedge_hedgemate-refresh-20260528_backtest_gated.csv
- portfolio_multi_gated_csv: C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\portfolio_multi_hedge_hedgemate-refresh-20260528_backtest_gated.csv

## Status Counts

- PASS_RECOMMEND: 0
- REFERENCE_ONLY: 42
- FAIL_GATE: 171
- INSUFFICIENT_DATA: 0

## Backtest Gate Counts

- VALIDATION_INSUFFICIENT: 35
- VALIDATION_NOT_ELIGIBLE: 171
- VALIDATION_THIN: 7

## Formal Gate Blocker Counts

- fail_gate: 171
- validation_not_eligible: 171
- liquidity_below_formal: 127
- return_drag_reference: 78
- reference_only: 42
- validation_insufficient: 35
- bootstrap_not_robust: 7
- cash_bootstrap_not_robust: 7
- validation_thin: 7
- cash_baseline_lag: 6

## Backtest Attribution Summary

- attribution_csv: C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\backtest_attribution_backtest-refresh-20260528.csv
- attribution_md: C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\backtest_attribution_backtest-refresh-20260528.md
- evaluated_count: 336
- improved_count: 327
- worsened_count: 9

| candidate | scenario | evaluated | worsened | worsened_rate | worst_metric | worst_delta | worst_case |
|---|---|---:|---:|---:|---|---:|---|
| ABBV | acute_global_stress_liquidity_crunch | 4 | 4 | 1.0 | cost_adjusted_return_drag | -0.317075 | 2023 US Regional Bank / Credit Stress |
| LLY | geopolitical_escalation_supply_shock | 2 | 2 | 1.0 | cost_adjusted_return_drag | -0.05032 | 2024 Middle East / Shipping Supply Shock |
| ABBV | geopolitical_escalation_supply_shock | 2 | 1 | 0.5 | cost_adjusted_return_drag | -0.104435 | 2024 Middle East / Shipping Supply Shock |
| SPLV | acute_global_stress_liquidity_crunch | 2 | 1 | 0.5 | cost_adjusted_return_drag | -0.116659 | 2023 US Regional Bank / Credit Stress |
| XLU | acute_global_stress_liquidity_crunch | 2 | 1 | 0.5 | cost_adjusted_return_drag | -0.117103 | 2023 US Regional Bank / Credit Stress |
| 132030.KS + EDV | acute_global_stress_liquidity_crunch | 2 | 0 | 0.0 | cost_adjusted_return_drag | -0.071815 | 2023 US Regional Bank / Credit Stress |
| 132030.KS + EDV | china_trade_fragmentation_shock | 1 | 0 | 0.0 | net_stress_loss | -0.112806 | China Slowdown / Property Stress |
| 132030.KS + EDV | geopolitical_escalation_supply_shock | 1 | 0 | 0.0 | cost_adjusted_return_drag | -0.026585 | 2024 Middle East / Shipping Supply Shock |
| 132030.KS + EDV | higher_for_longer_long_rate_shock | 1 | 0 | 0.0 | cash_net_stress_loss | -0.031546 | 2022 Global Rate Shock |
| 132030.KS + EDV | semiconductor_ai_cycle_shock | 1 | 0 | 0.0 | cost_adjusted_return_drag | -0.010835 | 2024 AI Semiconductor Concentration / Pullback Risk |

## Zero Formal Recommendation Message

- 현재 검증 기준에서 정식 추천 가능한 후보는 없습니다. 참고용 후보는 있으나, backtest evidence가 부족하거나 일부 구간에서 위험 악화가 확인되어 정식 추천으로 분류하지 않았습니다.

## Policy Audit

- WORSENED candidates still marked PASS_RECOMMEND: 0
- INSUFFICIENT_HISTORY-only candidates marked as successful PASS_RECOMMEND: 0
- Missing backtest evidence is treated as validation missing and cannot upgrade a formal recommendation.
- Combination candidates require evidence for the same combination; component evidence alone is not used for upgrade.

## Examples By Final Status

| recommendation_status | candidate | backtest_gate_status | worsened | insufficient_history | reason |
|---|---|---|---:|---:|---|
| PASS_RECOMMEND | - | - | 0 | 0 | no rows in this run |
| REFERENCE_ONLY | BTAL | VALIDATION_INSUFFICIENT | 0 | 0 | target-scenario historical validation has insufficient history; 검증 부족 |
| REFERENCE_ONLY | TLT | VALIDATION_INSUFFICIENT | 0 | 0 | target-scenario historical validation has insufficient history; 검증 부족 |
| REFERENCE_ONLY | VGLT | VALIDATION_INSUFFICIENT | 0 | 0 | target-scenario historical validation has insufficient history; 검증 부족 |
| REFERENCE_ONLY | EDV | VALIDATION_INSUFFICIENT | 0 | 0 | target-scenario historical validation has insufficient history; 검증 부족 |
| REFERENCE_ONLY | GOVT | VALIDATION_INSUFFICIENT | 0 | 0 | target-scenario historical validation has insufficient history; 검증 부족 |
| REFERENCE_ONLY | VGIT | VALIDATION_INSUFFICIENT | 0 | 0 | target-scenario historical validation has insufficient history; 검증 부족 |
| REFERENCE_ONLY | IEF | VALIDATION_INSUFFICIENT | 0 | 0 | target-scenario historical validation has insufficient history; 검증 부족 |
| REFERENCE_ONLY | FXY | VALIDATION_THIN | 0 | 0 | target-scenario backtest has only 1 evaluated stress case; 표본 부족 |
| REFERENCE_ONLY | XLP | VALIDATION_INSUFFICIENT | 0 | 0 | target-scenario historical validation has insufficient history; 검증 부족 |
| REFERENCE_ONLY | FXF | VALIDATION_INSUFFICIENT | 0 | 0 | target-scenario historical validation has insufficient history; 검증 부족 |
| FAIL_GATE | 261240.KS | VALIDATION_NOT_ELIGIBLE | 0 | 0 | candidate was not eligible for the bounded scenario backtest run |
| FAIL_GATE | 153130.KS | VALIDATION_NOT_ELIGIBLE | 0 | 0 | candidate was not eligible for the bounded scenario backtest run |
| FAIL_GATE | 132030.KS | VALIDATION_NOT_ELIGIBLE | 0 | 0 | candidate was not eligible for the bounded scenario backtest run |
| FAIL_GATE | USMV | VALIDATION_NOT_ELIGIBLE | 0 | 0 | candidate was not eligible for the bounded scenario backtest run |
| FAIL_GATE | 017670.KS | VALIDATION_NOT_ELIGIBLE | 0 | 0 | candidate was not eligible for the bounded scenario backtest run |
| FAIL_GATE | 068270.KS | VALIDATION_NOT_ELIGIBLE | 0 | 0 | candidate was not eligible for the bounded scenario backtest run |
| FAIL_GATE | NOBL | VALIDATION_NOT_ELIGIBLE | 0 | 0 | candidate was not eligible for the bounded scenario backtest run |
| FAIL_GATE | 055550.KS | VALIDATION_NOT_ELIGIBLE | 0 | 0 | candidate was not eligible for the bounded scenario backtest run |
| FAIL_GATE | SCHD | VALIDATION_NOT_ELIGIBLE | 0 | 0 | candidate was not eligible for the bounded scenario backtest run |
| FAIL_GATE | 005490.KS | VALIDATION_NOT_ELIGIBLE | 0 | 0 | candidate was not eligible for the bounded scenario backtest run |
| INSUFFICIENT_DATA | - | - | 0 | 0 | no rows in this run |
