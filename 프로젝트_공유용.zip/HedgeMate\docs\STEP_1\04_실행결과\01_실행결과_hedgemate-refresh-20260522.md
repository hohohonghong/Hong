# HedgeMate 데이터 파이프라인 실행 결과

- 실행일(UTC): 2026-05-22T05:25:25.830704+00:00
- 데이터 버전(data_version): 20260522
- 분석기간: 2007-01-01 ~ 2026-05-22
- 기준통화: KRW
- 대상 티커: 150개
- 수집 성공 티커: 150개
- 위기구간(stress) 일수: 269일
- 위기구간 벤치마크: SPY + ^KS200 (20거래일 -8%)
- 시나리오 벡터: `scenario_research\outputs\scenario_vectors\current_scenario_vector_final-refresh-20260522.csv`
- 현재 장세 요약: 현재 장세: 장기금리 부담장(ACTIVE, us_global, score=62.723495) / 달러강세/원화약세장(ACTIVE, fx_krw, score=57.838824) / 우호적 위험선호장(WATCH, us_global, score=57.358838)
- Active adverse scenario: 장기금리 부담장, 달러강세/원화약세장, 급성 리스크오프/유동성 경색장, 물가·에너지 재상승장, 중국·무역분절 충격장, 지정학 확전·공급충격장
- raw 재사용 여부(동일 data_version 재실행): NO
- FX raw 재사용 여부: NO

## DQ 요약(캘린더 기준)
- PASS: 27
- WARN: 122
- FAIL: 1
- 최소 coverage_ratio_calendar: 0.8496

## 지표 엔진 검증셋
- PASS: 7
- FAIL: 0
- 결측 처리 정책:
  - vol_annual 최소 관측치: 20
  - mdd_1y 최소 관측치: 20
  - var/cvar 최소 관측치: 60
  - beta 최소 교집합 관측치: 60
  - downside beta 최소 하락일: 20
  - corr 최소 관측치: 20

## 헷징 후보 Top 10 (KRW 기준)

| 순위 | 티커 | 버킷 | HES | Corr | CVaR | Stress | Sharpe | LiquidityPenalty | corr_sp500_60d_krw | cvar_95_1y_krw | sharpe_1y_krw_proxy | adv_60 |
|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | PSQ | inverse_etf | 0.3726 | 0.8877 | 0.6834 | 0.5168 | 0.1763 | 1.0000 | -0.2074 | -0.0274 | -1.0977 | 468735238362.81 |
| 2 | 153130.KS | kr_etf | 0.3721 | 0.7129 | 1.0000 | 0.4693 | 0.0000 | 1.0000 | 0.0303 | -0.0002 | -4.2686 | 4115245995.30 |
| 3 | SH | inverse_etf | 0.3693 | 0.8085 | 0.7349 | 0.5231 | 0.1923 | 1.0000 | -0.0996 | -0.0229 | -0.8098 | 717558300680.14 |
| 4 | TAIL | tail_risk_etf | 0.3619 | 0.6821 | 0.7985 | 0.5468 | 0.2162 | 1.0000 | 0.0723 | -0.0175 | -0.3796 | 10321404417.69 |
| 5 | 261240.KS | kr_etf | 0.3413 | 0.5567 | 0.8164 | 0.5244 | 0.2877 | 1.0000 | 0.2429 | -0.0159 | 0.9061 | 2149430070.08 |
| 6 | BTC-USD | crypto | 0.3284 | 0.2901 | 0.3564 | 0.6868 | 0.1960 | 0.0000 | 0.6055 | -0.0554 | -0.7435 | 3849228863995787776.00 |
| 7 | 055550.KS | kr_stock | 0.3284 | 0.9766 | 0.5126 | 0.2322 | 0.3975 | 1.0000 | -0.3282 | -0.0420 | 2.8813 | 139636196353.31 |
| 8 | BTAL | equity_etf | 0.3240 | 0.7790 | 0.6259 | 0.4913 | 0.1632 | 1.0000 | -0.0595 | -0.0323 | -1.3333 | 19748817734.41 |
| 9 | 068270.KS | kr_stock | 0.3218 | 0.9967 | 0.4332 | 0.3619 | 0.2796 | 1.0000 | -0.3556 | -0.0489 | 0.7614 | 118192870571.67 |
| 10 | 011200.KS | kr_stock | 0.3181 | 0.9525 | 0.4205 | 0.4313 | 0.2570 | 1.0000 | -0.2955 | -0.0499 | 0.3545 | 42501020016.50 |

## 포트폴리오 입력 분석 요약
- 입력 파일: `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\inputs\portfolio_weights_65d1988163af4b92a1f5f76a932a4f56.csv`
- 입력 제약조건 체크: PASS (합계 100%, 음수 금지, 단일자산 <=50%)
- 추천상태 분포: FAIL_GATE 47, PASS_RECOMMEND 2, REFERENCE_ONLY 21
- 1:1 최적 후보: XLV (최종점수 0.3280, CVaR 개선률 7.17%, Sharpe 개선률 3.17%)

## 산출 파일
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\raw\raw_market_daily_20260522.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\raw\raw_fx_daily_20260522.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\raw\raw_benchmark_daily_20260522.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\dq_result_hedgemate-refresh-20260522.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\processed\features_summary_hedgemate-refresh-20260522.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\metric_validation_hedgemate-refresh-20260522.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\hes_components_hedgemate-refresh-20260522.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\processed\asset_risk_sensitivity_hedgemate-refresh-20260522.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\asset_sensitivity_summary_hedgemate-refresh-20260522.md`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\processed\asset_scenario_sensitivity_hedgemate-refresh-20260522.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\asset_scenario_sensitivity_summary_hedgemate-refresh-20260522.md`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\asset_scenario_sensitivity_visual_hedgemate-refresh-20260522.html`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\recommendation_status_qa_hedgemate-refresh-20260522.md`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\portfolio_1to1_hedge_hedgemate-refresh-20260522.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\portfolio_multi_hedge_hedgemate-refresh-20260522.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\portfolio_compare_hedgemate-refresh-20260522.csv`
