# Hedge Action Plan

- run_id: hedgemate-refresh-20260528
- engine_version: hedge_action_engine_v1
- formal gate: 기존 PASS_RECOMMEND 기준을 완화하지 않음

## Portfolio
- MSFT: 19.671008287690857%
- NVDA: 19.671008287690857%
- AVGO: 10.062930506163566%
- XOM: 11.253036343073006%
- 011200.KS: 19.671008287690857%
- 207940.KS: 19.671008287690857%

## Status Counts
- FAIL_ACTION: 1
- REVIEW_ACTION: 35

## Top Vulnerabilities
- 장기금리·성장주 듀레이션 (rate_shock_growth_duration): net=0.32548015, sources=NVDA, MSFT, AVGO, offsets=-
- 지정학·공급망 충격 (geopolitical_supply_chain): net=0.16915232, sources=NVDA, 207940.KS, 011200.KS, offsets=-
- 달러강세·원화약세 (usdkrw_fx_korea): net=0.15775773, sources=207940.KS, 011200.KS, NVDA, offsets=MSFT, XOM, AVGO
- AI·반도체 사이클 (semiconductor_ai_cycle): net=0, sources=-, offsets=-
- 침체·유동성 스트레스 (recession_liquidity_stress): net=0, sources=-, offsets=-
- 물가·에너지 재상승 (inflation_energy_shock): net=0, sources=-, offsets=-
- 한국 내수·신용 스트레스 (korea_domestic_credit): net=0, sources=-, offsets=-

## Selected Actions
- REVIEW_ACTION · TRIM_AND_HEDGE · rate_shock_growth_duration: FXY / delta=-0.03224361 / turnover=10.000002% / reason=취약성 기여가 큰 보유자산이 확인되어 단순 추가 헷지보다 TRIM_AND_HEDGE가 우선입니다.
  - expected_effect: 취약성 0.0322 감소; CVaR 0.26%p 개선; MDD 1.80%p 개선; stress 0.00%p 악화; Sharpe 0.05 악화
  - formal_action_gap: FORMAL_ACTION excluded by action-level gate: bootstrap_not_robust|linked_formal_gate_blocked|linked_recommendation_not_formal|stress_after_cost_not_improved
- REVIEW_ACTION · TRIM_AND_HEDGE · geopolitical_supply_chain: EDV / delta=-0.01500049 / turnover=10.000002% / reason=취약성 기여가 큰 보유자산이 확인되어 단순 추가 헷지보다 TRIM_AND_HEDGE가 우선입니다.
  - expected_effect: 취약성 0.0150 감소; CVaR 0.27%p 개선; MDD 1.97%p 개선; stress 0.00%p 개선; Sharpe 0.03 악화
  - formal_action_gap: FORMAL_ACTION excluded by action-level gate: bootstrap_not_robust|linked_formal_gate_blocked|linked_recommendation_not_formal
- REVIEW_ACTION · TRIM_AND_HEDGE · usdkrw_fx_korea: BTAL / delta=-0.03909961 / turnover=10.000002% / reason=취약성 기여가 큰 보유자산이 확인되어 단순 추가 헷지보다 TRIM_AND_HEDGE가 우선입니다.
  - expected_effect: 취약성 0.0391 감소; CVaR 0.14%p 개선; MDD 1.89%p 개선; stress 0.01%p 개선; Sharpe 0.00 개선
  - formal_action_gap: FORMAL_ACTION excluded by action-level gate: linked_formal_gate_blocked|linked_recommendation_not_formal
- REVIEW_ACTION · TRIM_AND_HEDGE · rate_shock_growth_duration: 132030.KS + EDV / delta=-0.02738819 / turnover=10.000002% / reason=상위 sleeve 커버리지 이후 남은 후보 중 상태, 개선폭, turnover 기준으로 선택했습니다.
  - expected_effect: 취약성 0.0274 감소; CVaR 0.27%p 개선; MDD 1.67%p 개선; stress 0.01%p 악화; Sharpe 0.01 악화
  - formal_action_gap: FORMAL_ACTION excluded by action-level gate: bootstrap_not_robust|linked_formal_gate_blocked|linked_recommendation_not_formal|stress_after_cost_not_improved
- REVIEW_ACTION · TRIM_AND_HEDGE · rate_shock_growth_duration: 261240.KS + EDV / delta=-0.02705423 / turnover=10.000002% / reason=상위 sleeve 커버리지 이후 남은 후보 중 상태, 개선폭, turnover 기준으로 선택했습니다.
  - expected_effect: 취약성 0.0271 감소; CVaR 0.28%p 개선; MDD 1.95%p 개선; stress 0.00%p 악화; Sharpe 0.02 악화
  - formal_action_gap: FORMAL_ACTION excluded by action-level gate: bootstrap_not_robust|linked_formal_gate_blocked|linked_recommendation_not_formal|stress_after_cost_not_improved
- REVIEW_ACTION · TRIM_AND_HEDGE · geopolitical_supply_chain: TLT / delta=-0.01487676 / turnover=10.000002% / reason=상위 sleeve 커버리지 이후 남은 후보 중 상태, 개선폭, turnover 기준으로 선택했습니다.
  - expected_effect: 취약성 0.0149 감소; CVaR 0.27%p 개선; MDD 1.99%p 개선; stress 0.00%p 개선; Sharpe 0.03 악화
  - formal_action_gap: FORMAL_ACTION excluded by action-level gate: bootstrap_not_robust|linked_formal_gate_blocked|linked_recommendation_not_formal
- REVIEW_ACTION · TRIM_AND_HEDGE · geopolitical_supply_chain: GOVT / delta=-0.01435116 / turnover=10.000002% / reason=상위 sleeve 커버리지 이후 남은 후보 중 상태, 개선폭, turnover 기준으로 선택했습니다.
  - expected_effect: 취약성 0.0144 감소; CVaR 0.26%p 개선; MDD 1.91%p 개선; stress 0.00%p 개선; Sharpe 0.04 악화
  - formal_action_gap: FORMAL_ACTION excluded by action-level gate: bootstrap_not_robust|linked_formal_gate_blocked|linked_recommendation_not_formal
- REVIEW_ACTION · TRIM_AND_HEDGE · geopolitical_supply_chain: VGIT / delta=-0.01434616 / turnover=10.000002% / reason=상위 sleeve 커버리지 이후 남은 후보 중 상태, 개선폭, turnover 기준으로 선택했습니다.
  - expected_effect: 취약성 0.0143 감소; CVaR 0.25%p 개선; MDD 1.92%p 개선; stress 0.00%p 개선; Sharpe 0.04 악화
  - formal_action_gap: FORMAL_ACTION excluded by action-level gate: bootstrap_not_robust|linked_formal_gate_blocked|linked_recommendation_not_formal
- REVIEW_ACTION · TRIM_AND_HEDGE · geopolitical_supply_chain: ETH-USD / delta=-0.01377092 / turnover=10.000002% / reason=상위 sleeve 커버리지 이후 남은 후보 중 상태, 개선폭, turnover 기준으로 선택했습니다.
  - expected_effect: 취약성 0.0138 감소; CVaR 0.06%p 개선; MDD 0.82%p 개선; stress 0.04%p 개선; Sharpe 0.15 악화
  - formal_action_gap: FORMAL_ACTION excluded by action-level gate: cash_baseline_lag|linked_formal_gate_blocked|linked_recommendation_not_formal
- REVIEW_ACTION · TRIM_AND_HEDGE · geopolitical_supply_chain: BTC-USD / delta=-0.01372447 / turnover=10.000002% / reason=상위 sleeve 커버리지 이후 남은 후보 중 상태, 개선폭, turnover 기준으로 선택했습니다.
  - expected_effect: 취약성 0.0137 감소; CVaR 0.18%p 개선; MDD 1.00%p 개선; stress 0.03%p 개선; Sharpe 0.09 개선
  - formal_action_gap: FORMAL_ACTION excluded by action-level gate: cash_baseline_lag|linked_formal_gate_blocked|linked_recommendation_not_formal

## Action Type Coverage
- ADD_HEDGE: absent, not selected, count=0, selected=0 · matching recommendation row가 없거나 제약조건 안에서 위험 개선이 확인되지 않아 생성되지 않았습니다.
  - not_selected_reason: matching recommendation row가 없거나 제약조건 안에서 위험 개선이 확인되지 않아 생성되지 않았습니다.
- TRIM_AND_HEDGE: present, selected, count=36, selected=10 · 취약성 원인 보유자산을 일부 줄이고 헷지를 더하는 후보입니다.
- DE_RISK_CASH: absent, not selected, count=0, selected=0 · cash가 hedge보다 낫고 trim 자체가 비용 차감 후 위험을 낮춘다는 근거가 없어 formal cash 후보가 없습니다.
  - not_selected_reason: cash가 hedge보다 낫고 trim 자체가 비용 차감 후 위험을 낮춘다는 근거가 없어 formal cash 후보가 없습니다.
- REPLACE_SLEEVE: absent, not selected, count=0, selected=0 · 대체 proxy가 이미 보유 중이거나 해당 sleeve를 방어하지 않아 생성되지 않았습니다.
  - not_selected_reason: REPLACE_SLEEVE 후보가 없습니다. 대체 proxy가 이미 보유 중이거나, 해당 sleeve를 방어하지 못했거나, bounded turnover/집중도 제약 안에서 취약성을 줄이지 못했습니다.
- NO_ACTION: absent, not selected, count=0, selected=0 · 모든 취약 sleeve에서 최소 하나 이상의 bounded action 후보가 생성되어 NO_ACTION row가 필요하지 않았습니다.
  - not_selected_reason: 모든 취약 sleeve에서 최소 하나 이상의 bounded action 후보가 생성되어 NO_ACTION row가 필요하지 않았습니다.

## Next Validation Needed
- REVIEW_ACTION을 FORMAL_ACTION으로 올리려면 기존 formal recommendation gate, stress/backtest 근거, CVaR/MDD 안정성, 거래 제약 검증이 모두 충족되어야 합니다.
- FORMAL_ACTION이 없을 때는 실행 추천이 아니라 실행 전 검토용 시뮬레이션으로만 해석해야 합니다.
