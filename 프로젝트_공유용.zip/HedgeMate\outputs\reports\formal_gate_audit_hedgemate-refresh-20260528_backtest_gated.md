# Formal Gate Audit

- candidate_rows: 213
- status_counts: `{"PASS_RECOMMEND": 0, "REFERENCE_ONLY": 42, "FAIL_GATE": 171, "INSUFFICIENT_DATA": 0}`

## Blocker Counts

- fail_gate: 171 - 하드 게이트 실패 - Candidate failed a hard gate. Next action: Do not promote until the failing gate is resolved.
- validation_not_eligible: 171 - validation not eligible - Candidate is not eligible for backtest validation. Next action: Keep blocked or rebuild the candidate with valid backtest inputs.
- liquidity_below_formal: 127 - 유동성 기준 미달 - 60-day ADV evidence is missing or below the formal threshold. Next action: Refresh ADV evidence or exclude the candidate from formal recommendations.
- return_drag_reference: 78 - 수익률 훼손 검토 필요 - Pre-backtest scoring kept the candidate reference-only because of return drag. Next action: Confirm risk reduction compensates for return drag before promotion.
- reference_only: 42 - 참고 후보 - Candidate remains reference-only after formal gate checks. Next action: Use as research context, not an execution recommendation.
- validation_insufficient: 35 - 검증 이력 부족 - Target stress validation has insufficient history. Next action: Add enough target stress validation history before formal promotion.
- bootstrap_not_robust: 7 - 부트스트랩 신뢰도 부족 - Target stress bootstrap confidence is not robust. Next action: Increase sample coverage or downgrade fragile candidates.
- cash_bootstrap_not_robust: 7 - 현금 기준 부트스트랩 부족 - Cash-baseline bootstrap confidence is not robust. Next action: Add stronger cash-baseline evidence before formal use.
- validation_thin: 7 - 검증 표본 부족 - Target stress validation sample is too small for formal use. Next action: Keep review-only until the stress sample is thick enough.
- cash_baseline_lag: 6 - 현금 기준 대비 열위 - The hedge lags a cash-only de-risking baseline in target stress. Next action: Improve the cash-baseline comparison or keep the candidate review-only.

## Liquidity Capacity Audit

- BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE: 75
- MISSING_ADV: 52
- OK_ADV_FLOOR_NO_ORDER_SIZE: 86

| candidate | source | status | ADV KRW | order KRW | ADV usage % | capacity status |
|---|---|---|---:|---:|---:|---|
| 017670.KS | one_to_one | FAIL_GATE | 91327053576.37943 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |
| 017670.KS | one_to_one | FAIL_GATE | 91327053576.37943 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |
| 132030.KS | one_to_one | FAIL_GATE | 6688449669.583333 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |
| 132030.KS | one_to_one | FAIL_GATE | 6688449669.583333 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |
| 132030.KS + EDV | multi | REFERENCE_ONLY | 6688449669.583333 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |
| 132030.KS + EDV | multi | FAIL_GATE | 6688449669.583333 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |
| 132030.KS + EDV | multi | FAIL_GATE | 6688449669.583333 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |
| 132030.KS + GOVT | multi | REFERENCE_ONLY | 6688449669.583333 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |
| 132030.KS + GOVT | multi | FAIL_GATE | 6688449669.583333 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |
| 132030.KS + GOVT | multi | FAIL_GATE | 6688449669.583333 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |
| 132030.KS + VGLT | multi | REFERENCE_ONLY | 6688449669.583333 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |
| 132030.KS + VGLT | multi | FAIL_GATE | 6688449669.583333 |  |  | BELOW_FORMAL_ADV_FLOOR_NO_ORDER_SIZE |

## Highest-friction Candidates

| candidate | source | status | readiness | blockers | target eval | cash lags | robust/boot | min p | cash robust/boot | cash min p | min cash stress | reason |
|---|---|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---|
| FXY | one_to_one | REFERENCE_ONLY | 31.1 | validation_thin, cash_baseline_lag, bootstrap_not_robust, cash_bootstrap_not_robust, liquidity_below_formal, return_drag_reference, reference_only | 1 | 1 | 0/1 | 0.49 | 0/1 | 0.055 | -0.010663 | target-scenario backtest has only 1 evaluated stress case; 표본 부족 |
| 261240.KS + EDV | multi | REFERENCE_ONLY | 33.3 | validation_thin, cash_baseline_lag, bootstrap_not_robust, cash_bootstrap_not_robust, liquidity_below_formal, return_drag_reference, reference_only | 1 | 1 | 0/1 | 0.41 | 0/1 | 0.165 | -0.01285 | target-scenario backtest has only 1 evaluated stress case; 표본 부족 |
| FXE | one_to_one | REFERENCE_ONLY | 33.5 | validation_thin, cash_baseline_lag, bootstrap_not_robust, cash_bootstrap_not_robust, liquidity_below_formal, return_drag_reference, reference_only | 1 | 1 | 0/1 | 0.595 | 0/1 | 0.175 | -0.006592 | target-scenario backtest has only 1 evaluated stress case; 표본 부족 |
| 261240.KS + TLT | multi | REFERENCE_ONLY | 33.7 | validation_thin, cash_baseline_lag, bootstrap_not_robust, cash_bootstrap_not_robust, liquidity_below_formal, return_drag_reference, reference_only | 1 | 1 | 0/1 | 0.54 | 0/1 | 0.185 | -0.009131 | target-scenario backtest has only 1 evaluated stress case; 표본 부족 |
| 261240.KS + VGLT | multi | REFERENCE_ONLY | 33.8 | validation_thin, cash_baseline_lag, bootstrap_not_robust, cash_bootstrap_not_robust, liquidity_below_formal, return_drag_reference, reference_only | 1 | 1 | 0/1 | 0.54 | 0/1 | 0.19 | -0.008294 | target-scenario backtest has only 1 evaluated stress case; 표본 부족 |
| 261240.KS + GOVT | multi | REFERENCE_ONLY | 36.0 | validation_thin, cash_baseline_lag, bootstrap_not_robust, cash_bootstrap_not_robust, liquidity_below_formal, return_drag_reference, reference_only | 1 | 1 | 0/1 | 0.685 | 0/1 | 0.3 | -0.001796 | target-scenario backtest has only 1 evaluated stress case; 표본 부족 |
| 261240.KS + BTAL | multi | REFERENCE_ONLY | 61.0 | validation_thin, bootstrap_not_robust, cash_bootstrap_not_robust, liquidity_below_formal, return_drag_reference, reference_only | 1 | 0 | 0/1 | 0.695 | 0/1 | 0.55 | 0.001734 | target-scenario backtest has only 1 evaluated stress case; 표본 부족 |
| 017670.KS | one_to_one | FAIL_GATE | 10.0 | fail_gate, validation_not_eligible, liquidity_below_formal, return_drag_reference | 0 | 0 | 0/0 |  | 0/0 |  |  | candidate was not eligible for the bounded scenario backtest run |
| 132030.KS | one_to_one | FAIL_GATE | 10.0 | fail_gate, validation_not_eligible, liquidity_below_formal, return_drag_reference | 0 | 0 | 0/0 |  | 0/0 |  |  | candidate was not eligible for the bounded scenario backtest run |
| 153130.KS | one_to_one | FAIL_GATE | 10.0 | fail_gate, validation_not_eligible, liquidity_below_formal, return_drag_reference | 0 | 0 | 0/0 |  | 0/0 |  |  | candidate was not eligible for the bounded scenario backtest run |
| 261240.KS | one_to_one | FAIL_GATE | 10.0 | fail_gate, validation_not_eligible, liquidity_below_formal, return_drag_reference | 0 | 0 | 0/0 |  | 0/0 |  |  | candidate was not eligible for the bounded scenario backtest run |
| 132030.KS + EDV | multi | REFERENCE_ONLY | 20.0 | validation_insufficient, liquidity_below_formal, return_drag_reference, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |

## Closest Formal Near-misses

| candidate | source | status | readiness | blockers | target eval | cash lags | robust/boot | min p | cash robust/boot | cash min p | avg cash stress | reason |
|---|---|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---|
| 261240.KS + BTAL | multi | REFERENCE_ONLY | 61.0 | validation_thin, bootstrap_not_robust, cash_bootstrap_not_robust, liquidity_below_formal, return_drag_reference, reference_only | 1 | 0 | 0/1 | 0.695 | 0/1 | 0.55 | 0.001734 | target-scenario backtest has only 1 evaluated stress case; 표본 부족 |
| ABBV | one_to_one | REFERENCE_ONLY | 40.0 | validation_insufficient, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |
| LLY | one_to_one | REFERENCE_ONLY | 40.0 | validation_insufficient, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |
| LLY | one_to_one | REFERENCE_ONLY | 40.0 | validation_insufficient, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |
| WMT | one_to_one | REFERENCE_ONLY | 40.0 | validation_insufficient, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |
| ABBV | one_to_one | REFERENCE_ONLY | 40.0 | validation_insufficient, return_drag_reference, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |
| EDV | one_to_one | REFERENCE_ONLY | 40.0 | validation_insufficient, return_drag_reference, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |
| GOVT | one_to_one | REFERENCE_ONLY | 40.0 | validation_insufficient, return_drag_reference, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |
| IEF | one_to_one | REFERENCE_ONLY | 40.0 | validation_insufficient, return_drag_reference, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |
| JNJ | one_to_one | REFERENCE_ONLY | 40.0 | validation_insufficient, return_drag_reference, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |
| JNJ | one_to_one | REFERENCE_ONLY | 40.0 | validation_insufficient, return_drag_reference, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |
| SPLV | one_to_one | REFERENCE_ONLY | 40.0 | validation_insufficient, return_drag_reference, reference_only | 0 | 0 | 0/0 |  | 0/0 |  |  | target-scenario historical validation has insufficient history; 검증 부족 |
