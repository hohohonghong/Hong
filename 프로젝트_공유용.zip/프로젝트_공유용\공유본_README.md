# HedgeMate 프로젝트 공유본

이 폴더는 원본 프로젝트 폴더 없이 실행할 수 있도록 만든 팀 공유용 버전이다.

실행만 할 때는 Python이 필요하다. 프론트엔드는 이미 빌드된 `hedge-front/dist`를 Python 서버로 띄우도록 구성했다.

프론트엔드를 다시 빌드하거나 개발 서버로 실행하려면 Node.js와 npm이 추가로 필요하다.

## 포함한 것

- `hedge-front/`: React 프론트엔드 실행 소스
- `hedge-front/dist/`: 바로 실행 가능한 프론트엔드 빌드 결과
- `HedgeMate/`: Python 분석 엔진, API 서버, 기본 입력 데이터, 테스트
- `scenario_research/`: 장세 시나리오 리서치 소스, 입력 fixture, 테스트
- `HedgeMate/outputs/raw/`: 공유본 검증용 최소 market seed cache
- `docs/`: 루트 실행 결과 문서
- `팀공유용_프로젝트_정리.md`: 프로젝트 설명, 실행 방법, 역할 분담안
- `pytest.ini`, `conftest.py`: Python 테스트 설정
- `run.py`: 백엔드와 프론트엔드를 한 번에 실행
- `stop.py`: 실행한 서버 종료
- `refresh_market_data.py`: 시장데이터 빠른 갱신 또는 전체 재빌드
- `verify.py`: Python 테스트와 프론트엔드 빌드 검증
- `serve_frontend.py`: 빌드된 프론트엔드와 `/api` 프록시를 띄우는 Python 서버
- `requirements.txt`: 테스트 검증용 최소 Python 의존성

## 제외한 것

- `node_modules`
- `.pytest_cache`, `__pycache__`
- 대용량 `output`, `outputs`, `scenario_research/outputs`
- 대용량 원본 시세 cache와 반복 실행 산출물
- 브라우저 QA 캡처, 로그, 임시 실행 산출물
- 개인별 주차 보고서 `.docx`

## 가장 쉬운 실행 방법

공유본 루트로 이동한 뒤 실행한다. 이 방식은 `node_modules`가 없어도 동작한다.

```bash
python run.py
```

접속 주소:

```text
http://localhost:5173
```

종료:

```bash
python stop.py
```

기본 포트가 이미 사용 중이면 다른 포트로 실행할 수 있다.

```bash
python run.py --backend-port 18766 --frontend-port 15173
```

## 수동 실행 방법

백엔드:

```bash
cd HedgeMate
python scripts/serve_dashboard.py --port 8766
```

프론트엔드:

```bash
cd hedge-front
npm install
npm run dev
```

접속 주소:

```text
http://localhost:5173
```

## 시장데이터 갱신

빠른 갱신:

```bash
python refresh_market_data.py
```

이미 최신이어도 강제로 다시 확인:

```bash
python refresh_market_data.py --force
```

장세/추천 산출물까지 다시 만드는 전체 재빌드:

```bash
python refresh_market_data.py --mode full_rebuild --force
```

전체 재빌드는 시간이 오래 걸릴 수 있고 네트워크 연결이 필요하다. 일반 시연 전에는 빠른 갱신만 먼저 실행하면 된다.

## 검증 명령

한 번에 검증:

```bash
python verify.py
```

이 명령은 프론트엔드 재빌드를 포함하므로 Node.js와 npm이 필요하다. pytest가 없으면 먼저 `python -m pip install -r requirements.txt`를 실행한다.

Python 테스트:

```bash
pytest
```

프론트엔드 빌드:

```bash
cd hedge-front
npm run build
```

자세한 프로젝트 설명은 `팀공유용_프로젝트_정리.md`를 먼저 보면 된다.
