# Backtest Attribution

- attribution_rows: 266
- evaluated_count: 336
- improved_count: 327
- worsened_count: 9

## Top Worsened Candidate/Scenario Pairs

| candidate | scenario | evaluated | worsened | worsened_rate | worst_metric | worst_delta | worst_case |
|---|---|---:|---:|---:|---|---:|---|
| ABBV | acute_global_stress_liquidity_crunch | 4 | 4 | 1.0 | cost_adjusted_return_drag | -0.317075 | 2023 US Regional Bank / Credit Stress |
| LLY | geopolitical_escalation_supply_shock | 2 | 2 | 1.0 | cost_adjusted_return_drag | -0.05032 | 2024 Middle East / Shipping Supply Shock |
| ABBV | geopolitical_escalation_supply_shock | 2 | 1 | 0.5 | cost_adjusted_return_drag | -0.104435 | 2024 Middle East / Shipping Supply Shock |
| SPLV | acute_global_stress_liquidity_crunch | 2 | 1 | 0.5 | cost_adjusted_return_drag | -0.116659 | 2023 US Regional Bank / Credit Stress |
| XLU | acute_global_stress_liquidity_crunch | 2 | 1 | 0.5 | cost_adjusted_return_drag | -0.117103 | 2023 US Regional Bank / Credit Stress |
| 132030.KS + EDV | acute_global_stress_liquidity_crunch | 2 | 0 | 0.0 | cost_adjusted_return_drag | -0.071815 | 2023 US Regional Bank / Credit Stress |
| 132030.KS + EDV | china_trade_fragmentation_shock | 1 | 0 | 0.0 | net_stress_loss | -0.112806 | China Slowdown / Property Stress |
| 132030.KS + EDV | geopolitical_escalation_supply_shock | 1 | 0 | 0.0 | cost_adjusted_return_drag | -0.026585 | 2024 Middle East / Shipping Supply Shock |
