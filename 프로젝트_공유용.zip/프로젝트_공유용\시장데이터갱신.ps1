param(
    [ValidateSet("market_data_only", "full_rebuild")]
    [string]$Mode = "market_data_only",
    [int]$BackendPort = 8766,
    [switch]$Force
)

$ErrorActionPreference = "Stop"

$root = $PSScriptRoot
$logDir = Join-Path $root "runtime_logs"
New-Item -ItemType Directory -Path $logDir -Force | Out-Null

function Require-Command($name) {
    if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
        throw "$name command was not found. Install Python first."
    }
}

function Test-Backend($baseUrl) {
    try {
        $status = Invoke-RestMethod -Uri "$baseUrl/api/status" -TimeoutSec 5
        return [bool]$status.ok
    } catch {
        return $false
    }
}

Require-Command python

$apiBase = "http://127.0.0.1:$BackendPort"
$startedBackend = $false
$backend = $null

if (-not (Test-Backend $apiBase)) {
    $listener = Get-NetTCPConnection -LocalPort $BackendPort -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener) {
        throw "Port $BackendPort is already in use, but HedgeMate API did not respond at $apiBase."
    }
    $backend = Start-Process -FilePath "python" `
        -ArgumentList @("scripts/serve_dashboard.py", "--port", "$BackendPort") `
        -WorkingDirectory (Join-Path $root "HedgeMate") `
        -RedirectStandardOutput (Join-Path $logDir "market-refresh-backend.out.log") `
        -RedirectStandardError (Join-Path $logDir "market-refresh-backend.err.log") `
        -WindowStyle Hidden `
        -PassThru
    $startedBackend = $true
    Start-Sleep -Seconds 2
    if (-not (Test-Backend $apiBase)) {
        throw "Could not start HedgeMate API at $apiBase. Check runtime_logs."
    }
}

try {
    $payload = @{
        mode = $Mode
        force = [bool]$Force
        forceFullRefresh = ($Mode -eq "full_rebuild" -or [bool]$Force)
    } | ConvertTo-Json

    $job = Invoke-RestMethod `
        -Uri "$apiBase/api/refresh-market-data" `
        -Method Post `
        -ContentType "application/json" `
        -Body $payload `
        -TimeoutSec 30

    $jobId = $job.jobId
    if (-not $jobId) {
        throw "Refresh API did not return a jobId."
    }

    do {
        Start-Sleep -Seconds 2
        $job = Invoke-RestMethod -Uri "$apiBase/api/run-status?job_id=$jobId" -TimeoutSec 10
        $line = "status={0} stage={1} step={2}" -f $job.status, $job.stage, $job.currentStep
        Write-Host $line
    } while ($job.status -in @("queued", "running"))

    if ($job.status -notin @("completed", "skipped_latest")) {
        $errorText = $job.error
        if (-not $errorText) { $errorText = "unknown refresh failure" }
        throw $errorText
    }

    Write-Host ""
    Write-Host "Market refresh finished: $($job.status)"
    if ($job.result) {
        if ($job.result.latestMarketDate) {
            Write-Host "latestMarketDate: $($job.result.latestMarketDate)"
        }
        if ($job.result.rawPath) {
            Write-Host "rawPath: $($job.result.rawPath)"
        }
        if ($job.result.warning) {
            Write-Host "warning: $($job.result.warning)"
        }
        if ($job.result.reason) {
            Write-Host "reason: $($job.result.reason)"
        }
    }
} finally {
    if ($startedBackend -and $backend) {
        Stop-Process -Id $backend.Id -Force -ErrorAction SilentlyContinue
    }
}
