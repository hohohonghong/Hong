# Phase 6 Final Market State Summary

- 기준일: `2026-05-27`
- merge_engine_version: `phase6_final_market_state_v1`
- top_active_count: 3

## Top Active Scenarios
- `soft_landing_goldilocks` `ACTIVE` score=63.62, confidence=58.73, lens=us_global
- `usd_strength_krw_weakness` `ACTIVE` score=56.52, confidence=69.37, lens=fx_krw
- `higher_for_longer_long_rate_shock` `WATCH` score=52.24, confidence=59.03, lens=us_global
