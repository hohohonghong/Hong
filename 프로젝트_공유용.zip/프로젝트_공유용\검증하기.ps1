$ErrorActionPreference = "Stop"

$root = $PSScriptRoot

Push-Location $root
python -m pytest -q
Pop-Location

Push-Location (Join-Path $root "hedge-front")
if (-not (Test-Path "node_modules")) {
    npm ci
}
npm run build
Pop-Location

Write-Host "Verification complete: Python tests + frontend build"
