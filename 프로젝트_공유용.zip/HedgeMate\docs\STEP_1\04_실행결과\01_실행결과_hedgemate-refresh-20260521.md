# HedgeMate 데이터 파이프라인 실행 결과

- 실행일(UTC): 2026-05-21T02:27:06.392463+00:00
- 데이터 버전(data_version): 20260521
- 분석기간: 2007-01-01 ~ 2026-05-21
- 기준통화: KRW
- 대상 티커: 70개
- 수집 성공 티커: 70개
- 위기구간(stress) 일수: 269일
- 위기구간 벤치마크: SPY + ^KS200 (20거래일 -8%)
- 시나리오 벡터: `scenario_research\outputs\scenario_vectors\current_scenario_vector_final-refresh-20260521.csv`
- 현재 장세 요약: 현재 장세: 장기금리 부담장(STRESS, us_global, score=69.4392) / 달러강세/원화약세장(ACTIVE, fx_krw, score=66.531586) / 물가·에너지 재상승장(ACTIVE, us_global, score=55.51346)
- Active adverse scenario: 장기금리 부담장, 달러강세/원화약세장, 물가·에너지 재상승장, 중국·무역분절 충격장, 급성 리스크오프/유동성 경색장, 지정학 확전·공급충격장
- raw 재사용 여부(동일 data_version 재실행): NO
- FX raw 재사용 여부: NO

## DQ 요약(캘린더 기준)
- PASS: 8
- WARN: 62
- FAIL: 0
- 최소 coverage_ratio_calendar: 0.9667

## 지표 엔진 검증셋
- PASS: 7
- FAIL: 0
- 결측 처리 정책:
  - vol_annual 최소 관측치: 20
  - mdd_1y 최소 관측치: 20
  - var/cvar 최소 관측치: 60
  - beta 최소 교집합 관측치: 60
  - downside beta 최소 하락일: 20
  - corr 최소 관측치: 20

## 헷징 후보 Top 10 (KRW 기준)

| 순위 | 티커 | 버킷 | HES | Corr | CVaR | Stress | Sharpe | LiquidityPenalty | corr_sp500_60d_krw | cvar_95_1y_krw | sharpe_1y_krw_proxy | adv_60 |
|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | LQD | bond | 0.3901 | 0.0000 | 0.9661 | 0.7177 | 0.0939 | 0.0602 | 0.7887 | -0.0155 | 1.0871 | 6401526744290.50 |
| 2 | TLT | bond | 0.3861 | 0.0599 | 0.9121 | 1.0000 | 0.0000 | 0.3794 | 0.7236 | -0.0181 | 0.5906 | 4252853347279.98 |
| 3 | XLE | commodity_energy | 0.3659 | 0.6218 | 0.5831 | 0.3257 | 0.3287 | 0.3317 | 0.1132 | -0.0338 | 2.3283 | 4574034623685.00 |
| 4 | GLD | gold | 0.3511 | 0.2320 | 0.4298 | 0.7568 | 0.2286 | 0.0000 | 0.5366 | -0.0411 | 1.7995 | 6806991368010.73 |
| 5 | IEF | bond | 0.3358 | 0.0555 | 0.9829 | 0.9319 | 0.0680 | 0.8025 | 0.7284 | -0.0147 | 0.9502 | 1404446637609.38 |
| 6 | SHY | bond | 0.3321 | 0.1363 | 1.0000 | 0.8745 | 0.0748 | 0.9209 | 0.6406 | -0.0139 | 0.9863 | 607125729444.39 |
| 7 | DBC | commodity_energy | 0.2993 | 0.7595 | 0.6481 | 0.1765 | 0.4139 | 1.0000 | -0.0364 | -0.0307 | 2.7790 | 74612114417.76 |
| 8 | USO | commodity_energy | 0.2963 | 1.0000 | 0.0000 | 0.0000 | 0.3994 | 0.0910 | -0.2976 | -0.0617 | 2.7025 | 6194677504919.49 |
| 9 | TIP | bond | 0.2957 | 0.1162 | 0.9787 | 0.7611 | 0.0830 | 0.9511 | 0.6625 | -0.0149 | 1.0295 | 403938286913.04 |
| 10 | XLP | defensive | 0.2817 | 0.2170 | 0.8243 | 0.6206 | 0.0415 | 0.7263 | 0.5530 | -0.0223 | 0.8099 | 1917489640961.13 |

## 포트폴리오 입력 분석 요약
- 입력 파일: `HedgeMate\inputs\portfolio_weights.csv`
- 입력 제약조건 체크: PASS (합계 100%, 음수 금지, 단일자산 <=50%)
- 추천상태 분포: FAIL_GATE 40, PASS_RECOMMEND 2, REFERENCE_ONLY 27
- 1:1 최적 후보: GLD (최종점수 0.5596, CVaR 개선률 9.47%, Sharpe 개선률 3.95%)

## 산출 파일
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\raw\raw_market_daily_20260521.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\raw\raw_fx_daily_20260521.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\raw\raw_benchmark_daily_20260521.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\dq_result_hedgemate-refresh-20260521.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\processed\features_summary_hedgemate-refresh-20260521.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\metric_validation_hedgemate-refresh-20260521.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\hes_components_hedgemate-refresh-20260521.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\processed\asset_risk_sensitivity_hedgemate-refresh-20260521.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\asset_sensitivity_summary_hedgemate-refresh-20260521.md`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\processed\asset_scenario_sensitivity_hedgemate-refresh-20260521.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\asset_scenario_sensitivity_summary_hedgemate-refresh-20260521.md`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\asset_scenario_sensitivity_visual_hedgemate-refresh-20260521.html`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\recommendation_status_qa_hedgemate-refresh-20260521.md`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\portfolio_1to1_hedge_hedgemate-refresh-20260521.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\portfolio_multi_hedge_hedgemate-refresh-20260521.csv`
- `C:\Users\석민\Documents\cau_2026_ss\금융인공지능실습1\HedgeMate\outputs\reports\portfolio_compare_hedgemate-refresh-20260521.csv`
