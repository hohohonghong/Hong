# HedgeMate 분석 리포트 초안

## 0. 리포트 메타
- 작성일: 2026-04-15
- 작성자: 자동 파이프라인
- 데이터 버전: 20260311T191644822219-60e09191
- 분석 기간: 최근 5년 목표, 데이터 부족 시 가용 구간 기준 계산 허용
- 데이터 주기: 일봉
- 기준통화: KRW
- 위기구간 정의: SPY + ^KS200 20거래일 수익률 <= -8%

## 1. 데이터 품질 요약
- 수집 성공: 70/70
- DQ 판정(캘린더 기준): PASS 5, WARN 65, FAIL 0

## 2. 리스크 상위(KRW MDD 기준)
- BTC-USD: MDD_1y_krw=-0.4795, CVaR_95_1y_krw=-0.0553
- USO: MDD_1y_krw=-0.2479, CVaR_95_1y_krw=-0.0514
- XLE: MDD_1y_krw=-0.1993, CVaR_95_1y_krw=-0.0444
- DBC: MDD_1y_krw=-0.1457, CVaR_95_1y_krw=-0.0309
- TLT: MDD_1y_krw=-0.1404, CVaR_95_1y_krw=-0.0213

## 3. 헷징 후보 Top10
1. IAU (gold) - HES=0.4152 [Corr=0.827, CVaR=0.668, Stress=0.207, Sharpe=1.000, LiqPenalty=1.000]
2. GLD (gold) - HES=0.4129 [Corr=0.826, CVaR=0.664, Stress=0.207, Sharpe=0.994, LiqPenalty=1.000]
3. BTC-USD (crypto) - HES=0.3388 [Corr=0.147, CVaR=0.408, Stress=1.000, Sharpe=0.000, LiqPenalty=0.000]
4. USO (commodity_energy) - HES=0.3307 [Corr=1.000, CVaR=0.469, Stress=0.161, Sharpe=0.542, LiqPenalty=1.000]
5. DBC (commodity_energy) - HES=0.3031 [Corr=0.670, CVaR=0.787, Stress=0.000, Sharpe=0.593, LiqPenalty=1.000]
6. XLU (defensive) - HES=0.2951 [Corr=0.417, CVaR=0.846, Stress=0.221, Sharpe=0.568, LiqPenalty=1.000]
7. XLP (defensive) - HES=0.2640 [Corr=0.490, CVaR=0.865, Stress=0.151, Sharpe=0.299, LiqPenalty=1.000]
8. XLE (commodity_energy) - HES=0.2537 [Corr=0.628, CVaR=0.577, Stress=0.122, Sharpe=0.520, LiqPenalty=1.000]
9. IEF (bond) - HES=0.2344 [Corr=0.147, CVaR=0.992, Stress=0.251, Sharpe=0.328, LiqPenalty=1.000]
10. TLT (bond) - HES=0.2174 [Corr=0.245, CVaR=0.936, Stress=0.186, Sharpe=0.233, LiqPenalty=1.000]

## 4. 포트폴리오 개선 효과 (KRW 기준)
| 시나리오 | 변동성 | MDD | CVaR(95%) | 연환산수익률 | Sharpe | 변동성 개선률(%) | MDD 개선률(%) | CVaR 개선률(%) | Sharpe 개선률(%) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 기존 포트폴리오 | 0.205068 | -0.190808 | -0.025448 | 0.373135 | 1.673272 | 0.00 | 0.00 | 0.00 | 0.00 |
| 제안(1:1) - SHY | 0.185662 | -0.168326 | -0.023123 | 0.342539 | 1.683370 | 9.46 | 11.78 | 9.13 | 0.60 |
| 제안(다자산) - IAU + SHY | 0.186445 | -0.171196 | -0.023232 | 0.355945 | 1.748208 | 9.08 | 10.28 | 8.71 | 4.48 |

## 6. 다음 액션
- FX carry-forward 허용 범위 및 예외 처리 검토
- 단일 종목 질의 결과를 API/UI 입력 흐름에 연결
- 무위험수익률 실데이터 연결로 Sharpe proxy 고도화
