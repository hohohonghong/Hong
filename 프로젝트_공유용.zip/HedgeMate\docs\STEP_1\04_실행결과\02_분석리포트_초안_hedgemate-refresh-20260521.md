# HedgeMate 분석 리포트 초안

## 0. 리포트 메타
- 작성일: 2026-05-21
- 작성자: 자동 파이프라인
- 데이터 버전: 20260521
- 분석 기간: 최근 5년 목표, 데이터 부족 시 가용 구간 기준 계산 허용
- 데이터 주기: 일봉
- 기준통화: KRW
- 위기구간 정의: SPY + ^KS200 20거래일 수익률 <= -8%

- 현재 장세 요약: 현재 장세: 장기금리 부담장(STRESS, us_global, score=69.4392) / 달러강세/원화약세장(ACTIVE, fx_krw, score=66.531586) / 물가·에너지 재상승장(ACTIVE, us_global, score=55.51346)
## 1. 데이터 품질 요약
- 수집 성공: 70/70
- DQ 판정(캘린더 기준): PASS 8, WARN 62, FAIL 0

## 2. 리스크 상위(KRW MDD 기준)
- USO: MDD_1y_krw=-0.1814, CVaR_95_1y_krw=-0.0617
- GLD: MDD_1y_krw=-0.1531, CVaR_95_1y_krw=-0.0411
- XLE: MDD_1y_krw=-0.1425, CVaR_95_1y_krw=-0.0338
- DBC: MDD_1y_krw=-0.0803, CVaR_95_1y_krw=-0.0307
- XLP: MDD_1y_krw=-0.0716, CVaR_95_1y_krw=-0.0223

## 3. 헷징 후보 Top10
- 시나리오 벡터: `scenario_research\outputs\scenario_vectors\current_scenario_vector_final-refresh-20260521.csv`
1. LQD (bond) - HES=0.3901 [Corr=0.000, CVaR=0.966, Stress=0.718, Sharpe=0.094, LiqPenalty=0.060]
2. TLT (bond) - HES=0.3861 [Corr=0.060, CVaR=0.912, Stress=1.000, Sharpe=0.000, LiqPenalty=0.379]
3. XLE (commodity_energy) - HES=0.3659 [Corr=0.622, CVaR=0.583, Stress=0.326, Sharpe=0.329, LiqPenalty=0.332]
4. GLD (gold) - HES=0.3511 [Corr=0.232, CVaR=0.430, Stress=0.757, Sharpe=0.229, LiqPenalty=0.000]
5. IEF (bond) - HES=0.3358 [Corr=0.055, CVaR=0.983, Stress=0.932, Sharpe=0.068, LiqPenalty=0.802]
6. SHY (bond) - HES=0.3321 [Corr=0.136, CVaR=1.000, Stress=0.875, Sharpe=0.075, LiqPenalty=0.921]
7. DBC (commodity_energy) - HES=0.2993 [Corr=0.760, CVaR=0.648, Stress=0.177, Sharpe=0.414, LiqPenalty=1.000]
8. USO (commodity_energy) - HES=0.2963 [Corr=1.000, CVaR=0.000, Stress=0.000, Sharpe=0.399, LiqPenalty=0.091]
9. TIP (bond) - HES=0.2957 [Corr=0.116, CVaR=0.979, Stress=0.761, Sharpe=0.083, LiqPenalty=0.951]
10. XLP (defensive) - HES=0.2817 [Corr=0.217, CVaR=0.824, Stress=0.621, Sharpe=0.041, LiqPenalty=0.726]

## 4. 포트폴리오 개선 효과 (KRW 기준)
| 시나리오 | 변동성 | MDD | CVaR(95%) | 연환산수익률 | Sharpe | 변동성 개선률(%) | MDD 개선률(%) | CVaR 개선률(%) | Sharpe 개선률(%) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 기존 포트폴리오 | 0.217405 | -0.293939 | -0.029725 | 0.379462 | 1.607418 | 0.00 | 0.00 | 0.00 | 0.00 |
| 제안(1:1) - GLD | 0.198078 | -0.265593 | -0.026909 | 0.360982 | 1.670969 | 8.89 | 9.64 | 9.47 | 3.95 |

## 6. 다음 액션
- FX carry-forward 허용 범위 및 예외 처리 검토
- 단일 종목 질의 결과를 API/UI 입력 흐름에 연결
- 무위험수익률 실데이터 연결로 Sharpe proxy 고도화
