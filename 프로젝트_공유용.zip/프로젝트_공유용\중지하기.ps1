$ErrorActionPreference = "SilentlyContinue"

$logDir = Join-Path $PSScriptRoot "runtime_logs"
@("frontend.pid", "backend.pid") | ForEach-Object {
    $pidPath = Join-Path $logDir $_
    if (Test-Path $pidPath) {
        $processId = Get-Content $pidPath | Select-Object -First 1
        if ($processId) {
            Stop-Process -Id ([int]$processId) -Force
            Remove-Item $pidPath -Force
        }
    }
}

Write-Host "HedgeMate processes stopped."
