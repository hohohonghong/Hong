param(
    [int]$BackendPort = 8766,
    [int]$FrontendPort = 5173
)

$ErrorActionPreference = "Stop"

$root = $PSScriptRoot
$logDir = Join-Path $root "runtime_logs"
New-Item -ItemType Directory -Path $logDir -Force | Out-Null

function Require-Command($name) {
    if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
        throw "$name command was not found. Install Python, Node.js, and npm first."
    }
}

function Assert-PortFree($port) {
    $connection = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($connection) {
        throw "Port $port is already in use. Stop the existing server and try again."
    }
}

Require-Command python
Assert-PortFree $BackendPort
Assert-PortFree $FrontendPort

$distDir = Join-Path $root "hedge-front\dist"
if (-not (Test-Path (Join-Path $distDir "index.html"))) {
    throw "hedge-front/dist is missing. Run 검증하기.ps1 on a PC with Node.js, or rebuild with npm run build."
}

$backendOut = Join-Path $logDir "backend.out.log"
$backendErr = Join-Path $logDir "backend.err.log"
$frontendOut = Join-Path $logDir "frontend.out.log"
$frontendErr = Join-Path $logDir "frontend.err.log"

$backend = Start-Process -FilePath "python" `
    -ArgumentList @("scripts/serve_dashboard.py", "--port", "$BackendPort") `
    -WorkingDirectory (Join-Path $root "HedgeMate") `
    -RedirectStandardOutput $backendOut `
    -RedirectStandardError $backendErr `
    -WindowStyle Hidden `
    -PassThru

Set-Content -Path (Join-Path $logDir "backend.pid") -Value $backend.Id -Encoding UTF8

$frontend = Start-Process -FilePath "python" `
    -ArgumentList @("serve_frontend.py", "--port", "$FrontendPort", "--api-base", "http://127.0.0.1:$BackendPort") `
    -WorkingDirectory $root `
    -RedirectStandardOutput $frontendOut `
    -RedirectStandardError $frontendErr `
    -WindowStyle Hidden `
    -PassThru

Set-Content -Path (Join-Path $logDir "frontend.pid") -Value $frontend.Id -Encoding UTF8

Write-Host ""
Write-Host "HedgeMate started"
Write-Host "Frontend: http://localhost:$FrontendPort"
Write-Host "Backend : http://127.0.0.1:$BackendPort"
Write-Host "Logs    : $logDir"
Write-Host ""
Write-Host "Stop with the stop script in this folder."
