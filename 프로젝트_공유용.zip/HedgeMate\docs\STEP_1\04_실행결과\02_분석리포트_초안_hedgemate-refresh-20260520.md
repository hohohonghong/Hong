# HedgeMate 분석 리포트 초안

## 0. 리포트 메타
- 작성일: 2026-05-20
- 작성자: 자동 파이프라인
- 데이터 버전: 20260520
- 분석 기간: 최근 5년 목표, 데이터 부족 시 가용 구간 기준 계산 허용
- 데이터 주기: 일봉
- 기준통화: KRW
- 위기구간 정의: SPY + ^KS200 20거래일 수익률 <= -8%

- 현재 장세 요약: 현재 장세: 장기금리 부담장(STRESS, us_global, score=75.168279) / 물가·에너지 재상승장(ACTIVE, us_global, score=64.455958) / 달러강세/원화약세장(ACTIVE, fx_krw, score=63.208162)
## 1. 데이터 품질 요약
- 수집 성공: 70/70
- DQ 판정(캘린더 기준): PASS 8, WARN 62, FAIL 0

## 2. 리스크 상위(KRW MDD 기준)
- USO: MDD_1y_krw=-0.1814, CVaR_95_1y_krw=-0.0602
- GLD: MDD_1y_krw=-0.1531, CVaR_95_1y_krw=-0.0411
- XLE: MDD_1y_krw=-0.1425, CVaR_95_1y_krw=-0.0338
- DBC: MDD_1y_krw=-0.0803, CVaR_95_1y_krw=-0.0302
- XLP: MDD_1y_krw=-0.0716, CVaR_95_1y_krw=-0.0223

## 3. 헷징 후보 Top10
- 시나리오 벡터: `scenario_research\outputs\scenario_vectors\current_scenario_vector_final-refresh-20260520.csv`
1. XLE (commodity_energy) - HES=0.4175 [Corr=0.606, CVaR=0.570, Stress=0.326, Sharpe=0.737, LiqPenalty=0.348]
2. LQD (bond) - HES=0.4039 [Corr=0.000, CVaR=0.965, Stress=0.718, Sharpe=0.203, LiqPenalty=0.076]
3. GLD (gold) - HES=0.3948 [Corr=0.240, CVaR=0.412, Stress=0.757, Sharpe=0.536, LiqPenalty=0.000]
4. USO (commodity_energy) - HES=0.3842 [Corr=1.000, CVaR=0.000, Stress=0.000, Sharpe=1.000, LiqPenalty=0.105]
5. TLT (bond) - HES=0.3826 [Corr=0.060, CVaR=0.909, Stress=1.000, Sharpe=0.000, LiqPenalty=0.397]
6. DBC (commodity_energy) - HES=0.3808 [Corr=0.752, CVaR=0.648, Stress=0.177, Sharpe=0.970, LiqPenalty=1.000]
7. SHY (bond) - HES=0.3486 [Corr=0.135, CVaR=1.000, Stress=0.875, Sharpe=0.188, LiqPenalty=0.923]
8. IEF (bond) - HES=0.3468 [Corr=0.056, CVaR=0.982, Stress=0.932, Sharpe=0.146, LiqPenalty=0.808]
9. TIP (bond) - HES=0.3121 [Corr=0.115, CVaR=0.978, Stress=0.761, Sharpe=0.198, LiqPenalty=0.953]
10. XLP (defensive) - HES=0.2961 [Corr=0.206, CVaR=0.819, Stress=0.621, Sharpe=0.168, LiqPenalty=0.729]

## 4. 포트폴리오 개선 효과 (KRW 기준)
| 시나리오 | 변동성 | MDD | CVaR(95%) | 연환산수익률 | Sharpe | 변동성 개선률(%) | MDD 개선률(%) | CVaR 개선률(%) | Sharpe 개선률(%) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 기존 포트폴리오 | 0.185923 | -0.285282 | -0.025309 | 0.264146 | 1.259374 | 0.00 | 0.00 | 0.00 | 0.00 |
