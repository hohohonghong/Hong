#!/usr/bin/env python3
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def run(command, cwd):
    print("+", " ".join(command))
    subprocess.run(command, cwd=str(cwd), check=True)


def main():
    try:
        import pytest  # noqa: F401
    except ImportError:
        raise SystemExit("pytest is missing. Install it with: python -m pip install -r requirements.txt")

    run([sys.executable, "-m", "pytest", "-q"], ROOT)

    npm = shutil.which("npm.cmd") or shutil.which("npm")
    if not npm:
        raise SystemExit("npm is missing. Install Node.js to rebuild the frontend.")

    front_dir = ROOT / "hedge-front"
    if not (front_dir / "node_modules").exists():
        run([npm, "ci"], front_dir)
    run([npm, "run", "build"], front_dir)
    print("Verification complete: Python tests + frontend build")


if __name__ == "__main__":
    main()
