# HedgeMate 프론트-백엔드 연결 및 UI QA 보고서

- 작성일: 2026-05-27
- 프론트엔드: `http://127.0.0.1:5173`
- 백엔드: `http://127.0.0.1:8766`
- 브라우저 증거: `output/qa/hedgemate-browser/`

## 결론

통과.

백엔드가 `productStatus=STALE` 상태이더라도 `hedge`, `scenario`, `hedgeActionPlan`, `hedgeActionCandidates`, `portfolioVulnerabilitySummary` 등 표시 가능한 분석 데이터를 내려주는 경우 `/report`가 더 이상 "이 포트폴리오에 대한 최신 분석 결과가 없습니다" 카드로 막히지 않는다. 실제 브라우저에서 "저장된 분석 결과 표시 중" 배너와 취약점/헷지 액션 UI가 표시되는 것을 확인했다.

## 수정 사항

- `hedge-front/src/services/hedgemateViewModel.js`
  - `hasDisplayableReportData`, `reportDisplayReady` 기준으로 저장된 분석 결과를 표시.
  - `officialReportReady=false`이어도 백엔드 분석 데이터가 있으면 검토용 리포트 표시.
  - count 표시를 `reportDisplayReady` 기준으로 유지.

- `hedge-front/src/components/Layout.jsx`, `hedge-front/src/components/Layout.css`
  - 상단 알림/사용자 아이콘이 클릭 가능한 것처럼 보이지만 동작이 없던 문제 수정.
  - 두 아이콘 모두 `/settings`로 라우팅되도록 변경.

- `hedge-front/src/components/Sidebar.jsx`
  - `Logout` 버튼이 먹통이던 문제 수정.
  - 클릭 시 홈(`/`)으로 이동.

- `hedge-front/src/components/Button.css`
  - 실제로 여러 화면에서 쓰는 `outline` 버튼 스타일 추가.
  - disabled 버튼 hover/transform 방지.

- `hedge-front/src/pages/MyPortfolios.jsx`, `hedge-front/src/pages/MyPortfolios.css`
  - 저장 당시 `returnRate=0`만 표시하던 문제 수정.
  - `/api/portfolio/preview`에서 현재가, 현재 평가액, 종목별 `latestPrice/marketValueKrw`를 받아 카드 수익률을 동적으로 계산.
  - 카드에는 현재 평가액, 평가손익, 매입 기준 금액, 현재가 반영 상태를 표시.
  - 상세 펼침 표에는 종목별 현재가, 현재가 기준일, 손익, 수익률을 표시.

- `hedge-front/scripts/browserQa.mjs`
  - 실제 Chrome/Playwright 기반 QA 스크립트 추가.
  - `/settings`, `/portfolios`, `/report` 클릭 흐름, DOM 조건, viewport/full-page 스크린샷, 가로 overflow sanity check를 자동 수집.
  - 현재가 기반 비영(0이 아닌) 수익률 표시 검증 추가.

## 백엔드 API 확인

최종 확인 명령에서 다음을 확인했다.

- `GET /api/health`: `ok=true`
- `GET /api/status`: `ok=true`
- `GET /api/product-dashboard`
  - `productStatus=STALE`
  - `freshnessStatus=FRESH`
  - `hasHedge=true`
  - `hasScenario=true`
  - `actionPlanCount=10`
  - `candidateCount=60`
  - `activeHedgemateRun=20260522T162333711416-6e003a2d`
- 추가 확인:
  - `GET /api/assets`: `assetCount=152`
  - `GET /api/scenario-runs`: `scenarioRunCount=14`

## 브라우저 QA 확인

실행 명령:

```powershell
npm exec --yes --package playwright -- node scripts/browserQa.mjs
```

결과:

- `ok=true`
- `criticalFailures=[]`
- `failedRequestCount=0`
- `pageErrorCount=0`
- `ignoredAbortedRequestCount=1`
  - 라우트 전환 중 React abort controller가 `/api/portfolio/preview` 요청을 취소한 정상 abort로 분류.

주요 DOM 검증:

- 초기 `/report?portfolio=qa-active-bundle`
  - `hasStoredResultsBanner=true`
  - `hasNoLatestBlocker=false`
  - `hasActionPlan=true`
  - `hasCandidateDetails=true`
  - `productStatusVisible=true`
  - `horizontalOverflow=false`

- `/settings`
  - 프로필 수정 모달 저장 성공: `profileSaved=true`
  - 테마 버튼 존재: `hasThemeControls=true`
  - `horizontalOverflow=false`

- `/portfolios`
  - QA 포트폴리오 표시: `hasSeededPortfolio=true`
  - 현재가 수익률 검증 포트폴리오 표시: `hasPriceMovementPortfolio=true`
  - 삭제 모달 취소 후 포트폴리오 유지: `deleteCancelKeptPortfolio=true`
  - `분석 리포트 보기`, `수정` 버튼 표시: true
  - 현재가 반영 상태 표시: `hasLivePriceRefresh=true`
  - 현재가 기반 비영 수익률 표시: `priceMovementHasNonZeroReturn=true`
  - 상세 표 현재가/손익 컬럼 표시: `priceMovementHasCurrentPriceColumns=true`
  - `horizontalOverflow=false`

  검증 샘플:

  ```text
  QA Price Movement
  +16.1%
  현재 평가액 ₩3,721,404
  +₩515,404
  현재가 반영됨 · 2026. 5. 27.
  005930.KS 현재가 ₩307,000 / 손익 +₩140,000 / +4.8%
  NVDA 현재가 $214.86 / 손익 +₩351,456 / +117.2%
  ```

- `/report` 재진입
  - 포트폴리오 카드의 `분석 리포트 보기` 버튼으로 `/report?portfolio=qa-active-bundle` 이동 성공.
  - `hasStoredResultsBanner=true`
  - `hasNoLatestBlocker=false`
  - `hasReviewCounts=true`
  - `hasVulnerabilitySection=true`
  - `hasCandidateDetails=true`
  - `hasMetricSelection=true`
  - `horizontalOverflow=false`

- 상단/사이드바 버튼
  - 알림 아이콘: `/settings` 이동 확인.
  - 사용자 아이콘: `/settings` 이동 확인.
  - Logout: `/` 이동 확인.

## 스크린샷 증거

Viewport 기준으로 실제 사용자가 보는 화면을 확인했다. Full-page 캡처도 함께 저장했다.

- `/report` 저장 분석 결과 표시:
  - `output/qa/hedgemate-browser/01-report-stored-results-viewport.png`
  - `output/qa/hedgemate-browser/01-report-stored-results.png`
- `/settings` 프로필 저장/테마 UI:
  - `output/qa/hedgemate-browser/02-settings-after-profile-save-viewport.png`
  - `output/qa/hedgemate-browser/02-settings-after-profile-save.png`
- `/portfolios` 포트폴리오 확장/삭제 취소/리포트 버튼:
  - `output/qa/hedgemate-browser/03-portfolios-expanded-viewport.png`
  - `output/qa/hedgemate-browser/03-portfolios-expanded.png`
- `/report` 카드 버튼 재진입 및 후보 상세 열기:
  - `output/qa/hedgemate-browser/04-report-from-card-candidates-open-viewport.png`
  - `output/qa/hedgemate-browser/04-report-from-card-candidates-open.png`

참고: 긴 full-page 캡처에서는 fixed sidebar가 긴 페이지 하단 쪽에 보이는 캡처 특성이 있어, 실제 화면 레이아웃 판단은 viewport 캡처를 우선 증거로 사용했다.

## 정적 검증

```powershell
npm run lint
```

결과: 통과.

```powershell
npm run build
```

결과: 통과.

출력:

```text
built dist with 30 outputs
```

## 남은 리스크

- 백엔드 상태가 현재 `productStatus=STALE`, `freshnessStatus=FRESH`, `needsRefresh=true` 조합이라 화면에는 저장된 결과와 함께 시장데이터 갱신 경고가 표시된다. 이는 리포트 차단 오류가 아니라 현재 백엔드 freshness/gate 상태를 반영한 정상 경고로 판단했다.
- `npx vite build` 직접 실행은 Vite/Rolldown이 한글 원본 경로를 realpath로 해석하면서 `index.html` fileName 경로 오류를 낼 수 있다. 프로젝트의 공식 빌드 명령인 `npm run build`는 통과했다.
