# Phase 10E Rebalance-cost Path Walk-forward Backtest

- run_id: `backtest-refresh-20260528`
- historical_validation_run_id: `phase10a-wave5-20260514`
- hedgemate_run_id: `hedgemate-refresh-20260528`
- engine_version: `phase10e_rebalance_cost_path_walk_forward_v1`
- data_mode: API-free cached raw market prices
- transaction_cost_bps: 10
- slippage_bps: 5
- rebalance_frequency: `formation_only`
- bootstrap_iterations: 200
- bootstrap_ci_level: 0.95
- return_path_model: formation_only uses buy-and-hold weights; monthly/daily modes rebalance to target weights
- implementation_cost_model: one-time formation turnover cost deducted from proposed returns
- recurring_rebalance_cost_model: monthly/daily modes deduct turnover cost at each scheduled rebalance
- evaluated_rows: 336
- insufficient_history_rows: 42
- insufficient_evaluation_window_rows: 0
- out_of_price_range_rows: 0
- beats_cash_rows: 191
- lags_cash_rows: 145

## Verdict Counts
- IMPROVED: 327
- MIXED: 0
- WORSENED: 9
- INSUFFICIENT_HISTORY: 42

## Hedge vs Cash Baseline
- BEATS_CASH: 191
- MIXED_CASH: 0
- LAGS_CASH: 145

## Price Window Counts
- NO_COMMON_PRICE_DATES: 42
- PRICE_WINDOW_AVAILABLE: 336

## Price Blocking Tickers
- 207940.KS: 42
- AVGO: 42
- BTAL: 8
- 132030.KS: 5
- 153130.KS: 5
- 261240.KS: 5
- GOVT: 5
- VGLT: 5
- ABBV: 2
- SPLV: 1
- TAIL: 1
- VGIT: 1

## Pre-inception Tickers
- 207940.KS: 42
- AVGO: 42
- BTAL: 8
- 132030.KS: 5
- 153130.KS: 5
- 261240.KS: 5
- GOVT: 5
- VGLT: 5
- ABBV: 2
- SPLV: 1
- TAIL: 1
- VGIT: 1

## Missing Price Tickers
- none

## Notes
- Verdict counts use cost-adjusted proposed returns.
- Bootstrap intervals resample paired daily base/proposed-net returns by candidate and stress case.
- Insufficient-history cases are never counted as successful detection or backtest wins.
