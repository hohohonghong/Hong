# HedgeMate 분석 리포트 초안

## 0. 리포트 메타
- 작성일: 2026-05-07
- 작성자: 자동 파이프라인
- 데이터 버전: 20260507
- 분석 기간: 최근 5년 목표, 데이터 부족 시 가용 구간 기준 계산 허용
- 데이터 주기: 일봉
- 기준통화: KRW
- 위기구간 정의: SPY + ^KS200 20거래일 수익률 <= -8%

- 현재 장세 요약: 현재 장세: 우호적 위험선호장(PROVISIONAL, us_global, score=79.943622) / 물가·에너지 재상승장(WATCH, us_global, score=48.464917) / 장기금리 부담장(WATCH, us_global, score=46.248861)
## 1. 데이터 품질 요약
- 수집 성공: 70/70
- DQ 판정(캘린더 기준): PASS 5, WARN 65, FAIL 0

## 2. 리스크 상위(KRW MDD 기준)
- BTC-USD: MDD_1y_krw=-0.4795, CVaR_95_1y_krw=-0.0554
- USO: MDD_1y_krw=-0.1814, CVaR_95_1y_krw=-0.0588
- XLE: MDD_1y_krw=-0.1425, CVaR_95_1y_krw=-0.0323
- DBC: MDD_1y_krw=-0.0803, CVaR_95_1y_krw=-0.0288
- XLU: MDD_1y_krw=-0.0796, CVaR_95_1y_krw=-0.0243

## 3. 헷징 후보 Top10
- 시나리오 벡터: `../scenario_research/outputs/scenario_vectors/current_scenario_vector_latest-20260507.csv`
1. USO (commodity_energy) - HES=0.3980 [Corr=1.000, CVaR=0.315, Stress=0.350, Sharpe=0.995, LiqPenalty=1.000]
2. DBC (commodity_energy) - HES=0.3833 [Corr=0.768, CVaR=0.766, Stress=0.000, Sharpe=1.000, LiqPenalty=1.000]
3. XLE (commodity_energy) - HES=0.3383 [Corr=0.639, CVaR=0.712, Stress=0.106, Sharpe=0.862, LiqPenalty=1.000]
4. BTC-USD (crypto) - HES=0.3318 [Corr=0.131, CVaR=0.365, Stress=1.000, Sharpe=0.052, LiqPenalty=0.000]
5. XLU (defensive) - HES=0.2805 [Corr=0.339, CVaR=0.832, Stress=0.220, Sharpe=0.624, LiqPenalty=1.000]
6. SHY (bond) - HES=0.2468 [Corr=0.103, CVaR=1.000, Stress=0.253, Sharpe=0.470, LiqPenalty=1.000]
7. TIP (bond) - HES=0.2336 [Corr=0.106, CVaR=0.985, Stress=0.177, Sharpe=0.501, LiqPenalty=1.000]
8. IEF (bond) - HES=0.2306 [Corr=0.070, CVaR=0.982, Stress=0.230, Sharpe=0.477, LiqPenalty=1.000]
9. XLP (defensive) - HES=0.2142 [Corr=0.236, CVaR=0.866, Stress=0.127, Sharpe=0.422, LiqPenalty=1.000]
10. LQD (bond) - HES=0.2112 [Corr=0.000, CVaR=0.969, Stress=0.192, Sharpe=0.537, LiqPenalty=1.000]

## 4. 포트폴리오 개선 효과 (KRW 기준)
| 시나리오 | 변동성 | MDD | CVaR(95%) | 연환산수익률 | Sharpe | 변동성 개선률(%) | MDD 개선률(%) | CVaR 개선률(%) | Sharpe 개선률(%) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 기존 포트폴리오 | 0.202856 | -0.190808 | -0.025169 | 0.325342 | 1.455925 | 0.00 | 0.00 | 0.00 | 0.00 |
| 제안(1:1) - SHY | 0.183736 | -0.168326 | -0.022882 | 0.300523 | 1.472350 | 9.43 | 11.78 | 9.09 | 1.13 |
| 제안(다자산) - SHY + IAU | 0.184545 | -0.171196 | -0.022968 | 0.311633 | 1.526088 | 9.03 | 10.28 | 8.75 | 4.82 |

## 5. 단일 종목 질의 결과 (005930.KS)
- 기준(005930.KS 100%): CVaR=-0.040969, MDD=-0.428474, Sharpe=0.830294
- 제안(1:1) - BTC-USD: CVaR=-0.037004, MDD=-0.368295, Sharpe=0.802647
- 제안(다자산) - BTC-USD + SHY: CVaR=-0.037008, MDD=-0.402887, Sharpe=0.700125

## 6. 다음 액션
- FX carry-forward 허용 범위 및 예외 처리 검토
- 단일 종목 질의 결과를 API/UI 입력 흐름에 연결
- 무위험수익률 실데이터 연결로 Sharpe proxy 고도화
